<html lang="ru">
<head lang="<?php echo $str_language; ?>" xml:lang="<?php echo $str_language; ?>">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Продукция</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <style type="text/css">
        .center-div
        {
             margin: 50px 0 auto;
             width: 100px; 
        }
        html {
            display: table;
            margin: auto;
        }
        
    </style>
    
</head>
<body class="parent">
    <div style="center-div">
        <header class="bd-header bg-dark py-3 d-flex align-items-stretch border-bottom border-dark">
          <div class="container-fluid d-flex align-items-center">
            <h1 class="d-flex align-items-center fs-4 text-white mb-0">
              <a href="http://altles.ru/"><img src="images/logo.jpg" width="115" height="60" class="me-3" alt="Bootstrap" herf="http://altles.ru/"><ya-tr-span data-index="0-0" data-translated="false" data-source-lang="en" data-target-lang="ru" data-value=" " data-ch="0" data-type="trSpan" data-selected="false"></a> </ya-tr-span></h1>
            <a href="tel:+79039499351" class="ms-auto link-light" hreflang="ar"><ya-tr-span data-index="1-0" data-translated="false" data-source-lang="en" data-target-lang="ru" data-value="" data-translation="Чит-лист RTL" data-ch="0" data-type="trSpan" style="color: #8fbc8f">Позвонить</ya-tr-span></a>
          </div>
        </header>
        
    	<header bgcolor="#c4dfc0" class="site-header sticky-top py-1">
            <nav class="container d-flex flex-column flex-md-row bg-dark justify-content-between">
                
                <a class="py-2 d-none d-md-inline-block" href="" style="color: #98FB98"></a>
                <a class="py-2 d-none d-md-inline-block" href="about_us.html" style="color: #e0dfca">О компании</a>
                <a class="py-2 d-none d-md-inline-block" href="http://altles.ru/products.php" style="color: #e0dfca">Продукция</a>
                <a class="py-2 d-none d-md-inline-block" href="contacts_location.html" style="color: #e0dfca">Контакты</a>
                <a class="py-2 d-none d-md-inline-block" href=""></a>
            </nav>
        </header>

    <main>
    
        <div class="child">
          <div class="d-md-flex flex-md-equal w-100 my-md-3 ps-md-3">
            <div class="text-bg-dark me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 py-3">
                <h2 class="display-5">Бани</h2>
              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                  <img src="images/Ban2.jpg" width="250" height="230" align="center" hspace="55">
                  <p class="lead"> </p>
                    <div>
                        <a class="btn btn-outline-secondary" href="http://altles.ru/bathhouses.html" style="color: #8fbc8f">К описанию</a>
                    </div>
              </div>
            </div>
            <div class="bg-light me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 p-3">
                <h2 class="display-5">Качели</h2>
              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                    <img src="images/izd.jpg" width="300" height="220" align="center" hspace="25">
                    <p class="lead"> </p>
                    <div>
                        <a class="btn btn-outline-secondary" href="izd.html" style="color: #8fbc8f">К описанию</a>
                    </div>
            </div>
          </div>
        </div>
        </div>
    
        <div class="child">
          <div class="d-md-flex flex-md-equal w-100 my-md-3 ps-md-3">
            
            <div class="bg-light me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 p-3">
                <h2 class="display-5">Дома</h2>
              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                    <img src="images/home0.jpg" width="300" height="220" align="center" hspace="25">
                    <p class="lead"> </p>
                    <div>
                        <a class="btn btn-outline-secondary" href="home1.html" style="color: #8fbc8f">К описанию</a>
                    </div>
            </div>
          </div>
          <div class="text-bg-dark me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 py-3">
                <h2 class="display-5">Туалеты</h2>
              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                  <img src="images/toylet.jpg" width="300" height="220" align="center" hspace="25">
                  <p class="lead"> </p>
                    <div>
                        <a class="btn btn-outline-secondary" href="" style="color: #8fbc8f">К описанию</a>
                    </div>
              </div>
            </div>
        </div>
        </div>
        
        <div class="child">
          <div class="d-md-flex flex-md-equal w-100 my-md-3 ps-md-3">
            <div class="text-bg-dark me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 py-3">
                <h2 class="display-5" style=" font-size:36px">Пиломатериалы</h2>
              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                    <img src="images/pilomateriali.jpg">
                    <p class="lead"> </p>
                    <div>
                        <a class="btn btn-outline-secondary" href="dosk.html" style="color: #8fbc8f">К описанию</a>
                    </div>
              </div>
            </div>
            <div class="bg-light me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
              <div class="my-3 p-3">
                <h2 class="display-5" style="font-size:36px" href="brew.html">Бревно оцилиндрованное</h2>

              </div>
              <div style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
                <img src="images/brevno.jpg" width="360" height="220" align="center" hspace="15">
                <p class="lead"> </p>
                <div>
                    <a class="btn btn-outline-secondary" href="brew.html" style="color: #8fbc8f">К описанию</a>
                </div>
              </div>
          </div>
        </div>


    </main>
    <div class="bg-dark collapse show" id="navbarHeader" style="color: #e0dfca">
            <div class="container">
              <div class="row">
                <div class="col-sm-4 offset-md-1 py-4">
                </div>
              </div>
            </div>
        </div>
            
            <p style="text-align:right;">
            <font style="font:bold italic;color:#ccc;">Компания АлтЛес</font>
    </div>
</body>
</html>