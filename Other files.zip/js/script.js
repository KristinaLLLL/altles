/*menu.onClick = function myFunction() {
    var x = document.getElementById("myTopnav");
    
    if(x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}*/
var x = document.getElementById("myTopnav");
window.onload = function(){
    let x = document.querySelector("#myTopnav");
    document.querySelector("#menu").onclick = function(){
         x.classList.toggle('responsive');
    }
}