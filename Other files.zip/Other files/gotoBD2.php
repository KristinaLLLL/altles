<html>
    <head>
        <h2>Введите дату и нажмите кнопку Начать</h2>
    </head>
    <body>
    <form method='POST' action='upload2.php' enctype='multipart/form-data'>
    <div><input type='date' name='_date'></div>
    <div>
        <h3>Введите название базы</h3>
    </div>
    <div><input type='text' name='base'></div>
    <div>
        <h3>Введите поставщика</h3>
    </div>
    <div><input type='text' name='deliver'></div>
    <div>
        <h2> </h2>
    </div>
    <div><button type='submit' name='gotoBD2'> Начать </button></div>
    </form>
</html>