<html>
    <head>
      <style type="text/css">
        table {
            border: 1px solid grey;
            width: 100%;
        }
        /* границы ячеек первого ряда таблицы */
        th {
           border: 1px solid grey;
        }
        /* границы ячеек тела таблицы */
        td {
           border: 1px solid grey;
        }
      </style>
    </head>
</html>
<?php
header('Content-Type: text/html; charset=utf-8');
$db = mysqli_connect('localhost', 'a0581703_app_forest', '121133', 'a0581703_app_forest')or die('Connection error.');
  echo $_POST['num'];
  echo $_POST['text'];
  
  
  if (isset($_POST['show2'])) {
  
  $_date1 = mysqli_real_escape_string($db, $_POST['date1']);
  $_date2 = mysqli_real_escape_string($db, $_POST['date2']);
  $base = mysqli_real_escape_string($db, $_POST['base']);
	
  $execItems = $db->query("SELECT * FROM pilmat WHERE _date >= '$_date1' and _date <= '$_date2' and base ='$base'");

  $sumCub = 0;
  $sumQ = 0;
  echo '<table>';
  echo '<tr>';
  echo '<th>Дата</th><th>Высота</th><th>Ширина</th><th>Длина</th><th>Кубатура общая</th><th>Кубатура 1шт.</th><th>Количество</th><th>Поставщик</th>';
  echo '</tr>';
  while($infoItems = $execItems->fetch_array()){
	 $id = $infoItems['id'];
	 $_hight = $infoItems['_hight'];
     $_width = $infoItems['_width'];
     $_length = $infoItems['_length'];
     $quantity = $infoItems['quantity'];
     $cub_general = $infoItems['cub_general'];
     $cub_piece = $infoItems['cub_piece'];
     $_date = $infoItems['_date'];
     $base = $infoItems['base'];
     $deliver = $infoItems['deliver'];
     $sumCub = $sumCub + $cub_general;
     $sumQ = $sumQ + $quantity;
     echo '<tr>';
     echo '<td>'.$_date.'</td><td>'.$_hight.'</td><td>'.$_width.'</td><td>'.$_length.'</td><td>'.$cub_general.'</td><td>'.$cub_piece.'</td><td>'.$quantity.'</td><td>'.$deliver.'</td>';
     echo '</tr>';
  }
  echo '<tr>';
  echo '<td>Итоги:</td><td>-</td><td>-</td><td>-</td><td>'.$sumCub.'</td><td>-</td><td>'.$sumQ.'</td>';
  echo '</tr>';
  echo '</table>';
  }