<html>
    <head>
      <style type="text/css">
        table {
            border: 1px solid grey;
            width: 100%;
        }
        /* границы ячеек первого ряда таблицы */
        th {
           border: 1px solid grey;
        }
        /* границы ячеек тела таблицы */
        td {
           border: 1px solid grey;
        }
      </style>
    </head>
</html>
<?php
header('Content-Type: text/html; charset=utf-8');
$db = mysqli_connect('localhost', 'a0581703_app_forest', '121133', 'a0581703_app_forest')or die('Connection error.');
  echo $_POST['num'];
  echo $_POST['text'];
  
  if (isset($_POST['send'])) {
  // receive all input values from the form
  //$name = mysqli_real_escape_string($db, $_POST['text']);
  
  $_date = mysqli_real_escape_string($db, $_POST['_date']);
  $height = mysqli_real_escape_string($db, $_POST['height']);
  $width = mysqli_real_escape_string($db, $_POST['width']);
  $_length = mysqli_real_escape_string($db, $_POST['_length']);
  $quantity = mysqli_real_escape_string($db, $_POST['quantity']);
  $found = mysqli_real_escape_string($db, $_POST['found']);
  //echo $_POST['text'];
	
  // отрабатываем ошибки (выводим предупреждение)
  //if (empty($name)) { array_push($errors, "Name is required"); }


  // Регистрируем пользователя, если нет ошибок

  $query = "INSERT INTO test (_date, height, width, _length, quantity, found) VALUES ('$_date', '$height', '$width', '$_length', '$quantity', '$found')";
  mysqli_query($db, $query);
  	
  }
  
  if (isset($_POST['show'])) {
  // receive all input values from the form
  //$name = mysqli_real_escape_string($db, $_POST['text']);
  
  $_date1 = mysqli_real_escape_string($db, $_POST['date1']);
  $_date2 = mysqli_real_escape_string($db, $_POST['date2']);
  $base = mysqli_real_escape_string($db, $_POST['base']);
  //echo $_POST['text'];
	
  // отрабатываем ошибки (выводим предупреждение)
  //if (empty($name)) { array_push($errors, "Name is required"); }


  // Регистрируем пользователя, если нет ошибок

  //$query = "SELECT * INTO test WHERE _date >='$_date1' and _date<='$_date2'";
  //mysqli_query($db, $query);
  $execItems = $db->query("SELECT * FROM crugl WHERE _date >= '$_date1' and _date <= '$_date2' and base ='$base'");
  //echo $execItems;
  $sumCub = 0;
  $sumQ = 0;
  echo '<table>';
  echo '<tr>';
  echo '<th>Дата</th><th>Диаметр</th><th>Длина</th><th>Кубатура</th><th>Количество</th><th>Поставщик</th>';
  echo '</tr>';
  while($infoItems = $execItems->fetch_array()){
	 $id = $infoItems['_id'];
	 $_date = $infoItems['_date'];
     $diameter = $infoItems['diameter'];
     $_length = $infoItems['length'];
     $cubature = $infoItems['cubature'];
     $quantity = $infoItems['quantity'];
     $base = $infoItems['base'];
     $deliver = $infoItems['deliver'];
     $sumCub = $sumCub + $cubature;
     $sumQ = $sumQ + $quantity;
     echo '<tr>';
     echo '<td>'.$_date.'</td><td>'.$diameter.'</td><td>'.$_length.'</td><td>'.$cubature.'</td><td>'.$quantity.'</td><td>'.$deliver.'</td>';
     echo '</tr>';
  }
  echo '<tr>';
  echo '<td>Итоги:</td><td>-</td><td>-</td><td>'.$sumCub.'</td><td>'.$sumQ.'</td>';
  echo '</tr>';
  echo '</table>';
  }
 ?>