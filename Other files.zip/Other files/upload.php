<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
$db = mysqli_connect('localhost', 'a0581703_app_forest', '121133', 'a0581703_app_forest')or die('Connection error.');
$message = ''; 
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Загрузить')
{
  if (isset($_FILES['uploadedFile']) && $_FILES['uploadedFile']['error'] === UPLOAD_ERR_OK)
  {
    // get details of the uploaded file
    $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
    $fileName = $_FILES['uploadedFile']['name'];
    $_SESSION['namefile'] = $fileName;
    $fileSize = $_FILES['uploadedFile']['size'];
    $fileType = $_FILES['uploadedFile']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
   
    // sanitize file-name
    $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
    $_SESSION['namefile'] = $newFileName;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'doc');

    if (in_array($fileExtension, $allowedfileExtensions))
    {
      // directory in which the uploaded file will be moved
      $uploadFileDir = './uploaded_files/';
      $dest_path = $uploadFileDir . $newFileName;

      if(move_uploaded_file($fileTmpPath, $dest_path)) 
      {
        $message ='File is successfully uploaded.';
      }
      else 
      {
        $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
      }
    }
    else
    {
      $message = 'Upload failed. Allowed file types: ' . implode(',', $allowedfileExtensions);
    }
  }
  else
  {
    $message = 'There is some error in the file upload. Please check the following error.<br>';
    $message .= 'Error:' . $_FILES['uploadedFile']['error'];
  }
}
$_SESSION['message'] = $message;

///////////////////////////////////////////////////////////////////////////////////////////////////


if (isset($_POST['gotoBD'])){
    $_date = mysqli_real_escape_string($db, $_POST['_date']);
    $base = mysqli_real_escape_string($db, $_POST['base1']);
    $deliver = mysqli_real_escape_string($db, $_POST['deliver1']);
    $x = $_SESSION['namefile'];
    require_once 'PHPExcel-1.8/Classes/PHPExcel.php';
    $pExcel = PHPExcel_IOFactory::load("uploaded_files/$x");
    
    foreach ($pExcel->getWorksheetIterator() as $worksheet) {
        // выгружаем данные из объекта в массив
        $tables[] = $worksheet->toArray();
    }
    
    
    // выбираем лист, с которым будем работать
    $pExcel->setActiveSheetIndex(0);
    $aSheet = $pExcel->getActiveSheet();
    // получаем доступ к ячейке по номеру строки 
    // (нумерация с единицы) и столбца (нумерация с нуля) 
    $cell = $aSheet->getCellByColumnAndRow(3, 8);
    // читаем значение ячейки
    $v = $cell->getValue();
    
    echo "<table>";
    
    for ($i = 24; $i <= 100; $i++){
        echo "<tr>";
         
        $c = $aSheet->getCellByColumnAndRow(1, $i);
        $id = $c->getValue();
        if ($id > 0){
            $cell1 = $aSheet->getCellByColumnAndRow(2, $i);
            $v1 = $cell1->getValue();
            if (gettype($v1) == "string"){
                $v1 = doubleval($v1);
            }
            echo "<td><h1>$v1</h1></td>";
            
            $cell2 = $aSheet->getCellByColumnAndRow(3, $i);
            $v2 = $cell2->getValue();
            if (gettype($v2) == "string"){
                    $v2 = doubleval($v2);
                }
            echo "<td><h1>$v2</h1></td>";
               
            $cell3 = $aSheet->getCellByColumnAndRow(4, $i);
            $v3 = $cell3->getValue();
            if (gettype($v3) == "string"){
                    $v3 = doubleval($v3);
                }
            echo "<td><h1>$v3</h1></td>";
                
            $cell4 = $aSheet->getCellByColumnAndRow(5, $i);
            $v4 = $cell4->getValue();
            if (gettype($v4) == "string"){
                    $v4 = doubleval($v4);
                }
            echo "<td><h1>$v4</h1></td>";

            $query = "INSERT INTO crugl (diameter, length, quantity, cubature, _date, base, deliver) VALUES ('$v1', '$v2', '$v3', '$v4', '$_date', '$base', '$deliver')";
            mysqli_query($db, $query); 
        }
         
        echo "</tr>";
    }
        
    echo "</table>";

    $_SESSION['namefile'] = "";
}

header("Location: list.php");
