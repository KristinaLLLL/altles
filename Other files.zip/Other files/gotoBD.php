<html>
    <head>
        <h2>Введите дату и нажмите кнопку Начать</h2>
    </head>
    <body>
    <form method='POST' action='upload.php' enctype='multipart/form-data'>
    <div><input type='date' name='_date'></div>
    <h3>Введите наименование базы</h3>
    <div><input type='text' name='base1'></div>
    <h3>Введите поставщика</h3>
    <div><input type='text' name='deliver1'></div>
    <div><button type='submit' name='gotoBD'> Начать </button></div>
    </form>
</html>