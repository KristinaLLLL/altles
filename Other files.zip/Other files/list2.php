<!DOCTYPE html>
<?php
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
  <title>Пиломатериалы</title>
  <h1>Пиломатериалы</h1>
</head>
<body>
    <style>
        a.button24 {
          display: inline-block;
          color: white;
          text-decoration: none;
          padding: .5em 2em;
          outline: none;
          border-width: 2px 0;
          border-style: solid none;
          border-color: #FDBE33 #000 #D77206;
          border-radius: 6px;
          background: linear-gradient(#F3AE0F, #E38916) #E38916;
          transition: 0.2s;
        } 
        a.button24:hover { background: linear-gradient(#f5ae00, #f59500) #f5ae00; }
        a.button24:active { background: linear-gradient(#f59500, #f5ae00) #f59500; }
    </style>
  <?php
    if (isset($_SESSION['message']) && $_SESSION['message'])
    {
      printf('<b>%s</b>', $_SESSION['message']);
      printf('<b>%s</b>', $_SESSION['namefile']);
      unset($_SESSION['message']);
    }
  ?>
  <form method="POST" action="upload2.php" enctype="multipart/form-data">
    <div>
      <span>Загрузите файл:</span>
      <input type="file" name="uploadedFile2" />
    </div>
 
    <p><input type="submit" name="uploadBtn2" value="Загрузить сейчас" /></p>
  </form>
  <form method="POST" action="gotoBD2.php" enctype="multipart/form-data">
    <div>
        <input type="submit" name="readBtn2" value="Прочитать" />
    </div>
  </form>
  <h2> </h2>
  <a href="menuAdd.html" class="button24">К меню</a>
</body>
</html>