<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
$db = mysqli_connect('localhost', 'a0581703_app_forest', '121133', 'a0581703_app_forest')or die('Connection error.');
$message = ''; 

///////////////////////////////////////////////////////////////////////////////////////////////////

if (isset($_POST['uploadBtn2']) && $_POST['uploadBtn2'] == 'Загрузить сейчас')
{
  if (isset($_FILES['uploadedFile2']) && $_FILES['uploadedFile2']['error'] === UPLOAD_ERR_OK)
  {
    // get details of the uploaded file
    $fileTmpPath = $_FILES['uploadedFile2']['tmp_name'];
    $fileName2 = $_FILES['uploadedFile2']['name'];
    $_SESSION['namefile'] = $fileName2;
    $fileSize = $_FILES['uploadedFile2']['size'];
    $fileType = $_FILES['uploadedFile2']['type'];
    $fileNameCmps = explode(".", $fileName2);
    $fileExtension = strtolower(end($fileNameCmps));
   
    // sanitize file-name
    $newFileName2 = md5(time() . $fileName2) . '.' . $fileExtension2;
    $_SESSION['namefile'] = $newFileName2;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'doc');

    if (in_array($fileExtension, $allowedfileExtensions))
    {
      // directory in which the uploaded file will be moved
      $uploadFileDir2 = './uploaded_files/';
      $dest_path2 = $uploadFileDir2 . $newFileName2;

      if(move_uploaded_file($fileTmpPath, $dest_path2)) 
      {
        $message2 ='File is successfully uploaded.';
      }
      else 
      {
        $message2 = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
      }
    }
    else
    {
      $message2 = 'Upload failed. Allowed file types: ' . implode(',', $allowedfileExtensions);
    }
  }
  else
  {
    $message2 = 'There is some error in the file upload. Please check the following error.<br>';
    $message2 .= 'Error:' . $_FILES['uploadedFile2']['error'];
  }
}
$_SESSION['message'] = $message2;

///////////////////////////////////////////////////////////////////////////////////////



if (isset($_POST['gotoBD2'])){
    $_date = mysqli_real_escape_string($db, $_POST['_date']);
    $base = mysqli_real_escape_string($db, $_POST['base']);
    $deliver = mysqli_real_escape_string($db, $_POST['deliver']);
    $x = $_SESSION['namefile'];
    require_once 'PHPExcel-1.8/Classes/PHPExcel.php';
    $pExcel = PHPExcel_IOFactory::load("uploaded_files/$x");
    
    foreach ($pExcel->getWorksheetIterator() as $worksheet) {
        // выгружаем данные из объекта в массив
        $tables[] = $worksheet->toArray();
    }
    
    
    // выбираем лист, с которым будем работать
    $pExcel->setActiveSheetIndex(0);
    $aSheet = $pExcel->getActiveSheet();
    // получаем доступ к ячейке по номеру строки 
    // (нумерация с единицы) и столбца (нумерация с нуля) 
    $cell = $aSheet->getCellByColumnAndRow(3, 8);
    // читаем значение ячейки
    $v = $cell->getValue();
    
    echo "<table>";
    
    for ($i = 14; $i <= 100; $i++){
        echo "<tr>";
         
        $c = $aSheet->getCellByColumnAndRow(1, $i);
        $id = $c->getValue();
        if ($id > 0){
            $cell1 = $aSheet->getCellByColumnAndRow(2, $i);
            $v1 = $cell1->getValue();
            if (gettype($v1) == "string"){
                $v1 = doubleval($v1);
            }
            echo "<td><h1>$v1</h1></td>";
            
            $cell2 = $aSheet->getCellByColumnAndRow(4, $i);
            $v2 = $cell2->getValue();
            if (gettype($v2) == "string"){
                    $v2 = doubleval($v2);
                }
            echo "<td><h1>$v2</h1></td>";
               
            $cell3 = $aSheet->getCellByColumnAndRow(6, $i);
            $v3 = $cell3->getValue();
            if (gettype($v3) == "string"){
                    $v3 = doubleval($v3);
                }
            echo "<td><h1>$v3</h1></td>";
                
            $cell4 = $aSheet->getCellByColumnAndRow(8, $i);
            $v4 = $cell4->getValue();
            if (gettype($v4) == "string"){
                    $v4 = doubleval($v4);
                }
            echo "<td><h1>$v4</h1></td>";
            
            $cell5 = $aSheet->getCellByColumnAndRow(9, $i);
            $v5 = $cell5->getValue();
            if (gettype($v5) == "string"){
                    $v5 = doubleval($v5);
                }
            echo "<td><h1>$v5</h1></td>";
            
            $cell6 = $aSheet->getCellByColumnAndRow(10, $i);
            $v6 = $cell6->getValue();
            if (gettype($v6) == "string"){
                    $v6 = doubleval($v6);
                }
            echo "<td><h1>$v6</h1></td>";
            
            $query = "INSERT INTO pilmat (_hight, _width, _length, quantity, cub_general, cub_piece, _date, base, deliver) VALUES ('$v1', '$v2', '$v3', '$v4', '$v5', '$v6', '$_date', '$base', '$deliver')";
            mysqli_query($db, $query); 
        }
         
        echo "</tr>";
    }
        
    echo "</table>";

    $_SESSION['namefile'] = "";
}
header("Location: list2.php");
