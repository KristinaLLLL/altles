<?php
$a = 7 * 8;
return $a;
?>